================================================================
  CALL — Ready-to-Deploy Package
================================================================

This package contains everything you need to deploy CALL on your hosting.

WHAT'S INSIDE:
  app/                      — The complete Next.js standalone app
    production-server.js    — Start with: node production-server.js
    .env.example            — Copy to .env and fill in your DB credentials
    deploy/                 — MySQL SQL files for phpMyAdmin import
      call-mysql-full.sql     — Schema + seed data (RECOMMENDED)
      call-mysql-schema.sql    — Schema only (empty database)
    prisma/                 — Prisma schema (reference)
    README-DEPLOY.md        — Detailed deployment guide
  call-mysql-full.sql       — Same as app/deploy/ (root copy for easy access)
  call-mysql-schema-only.sql — Same as app/deploy/ (root copy)

QUICK START:
  1. Create a MySQL database in your hosting panel
  2. Import call-mysql-full.sql via phpMyAdmin (creates 43 tables + seed data)
  3. Upload the app/ folder to your hosting
  4. Copy .env.example to .env and fill in your DATABASE_URL
  5. Set the start command: node production-server.js
  6. Restart the app

See app/README-DEPLOY.md for the full guide.

ADMIN LOGIN (after deploy):
  Email: fahadqazi1111@gmail.com
  Password: 12345678
  (CHANGE THIS IMMEDIATELY after first login)

IMPORTANT:
  - For calls/live/rooms to work across networks, set up a TURN server
    and add NEXT_PUBLIC_CALL_ICE_SERVERS in .env
  - For email OTP, configure SMTP in Admin → Email/SMTP
  - For SMS OTP, configure Twilio in Admin → Authentication
  - For Google Sign-In, set Google Client ID in Admin → Authentication
================================================================
