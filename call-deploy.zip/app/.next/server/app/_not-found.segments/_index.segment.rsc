1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
:HL["/_next/static/css/7b736202f0b1dbfd.css","style"]
:HL["/_next/static/css/63a8c3e2cdb8cea0.css","style"]
0:{"buildId":"QWJatZgDpiqpBql3klw9a","rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/7b736202f0b1dbfd.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/css/63a8c3e2cdb8cea0.css","precedence":"next"}]],["$","html",null,{"lang":"en","suppressHydrationWarning":true,"children":[["$","head",null,{"children":["$","script",null,{"dangerouslySetInnerHTML":{"__html":"try{if(localStorage.getItem('call.splash')==='0')document.documentElement.dataset.splashOff='1'}catch(e){}"}}]}],["$","body",null,{"className":"__variable_d8ebd1 font-sans antialiased bg-background text-foreground","children":["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]}]]}]]}],"loading":null,"isPartial":false}
