1:"$Sreact.fragment"
2:I[7856,["8500","static/chunks/8500-41fa79ac743d83f1.js","1920","static/chunks/1920-020b9d8511453bce.js","8974","static/chunks/app/page-3b68db87dd4f34f1.js"],"AppRoot"]
3:I[484,[],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"ysPhH0z8UDOlLRdUD07j3","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
