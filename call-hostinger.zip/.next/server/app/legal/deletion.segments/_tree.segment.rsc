:HL["/_next/static/media/e4af272ccee01ff0-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/css/7b736202f0b1dbfd.css","style"]
:HL["/_next/static/css/03a2ca6f27bec51f.css","style"]
0:{"buildId":"ysPhH0z8UDOlLRdUD07j3","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"legal","paramType":null,"paramKey":"legal","hasRuntimePrefetch":false,"slots":{"children":{"name":"deletion","paramType":null,"paramKey":"deletion","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
