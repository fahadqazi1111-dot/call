1:"$Sreact.fragment"
2:I[484,[],"ViewportBoundary"]
3:I[484,[],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[6869,[],"IconMark"]
0:{"buildId":"ysPhH0z8UDOlLRdUD07j3","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover"}],["$","meta","2",{"name":"theme-color","content":"#0B1B40"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Community Guidelines — CALL"}],["$","meta","1",{"name":"description","content":"The rules of behaviour on CALL — calls, chats, voice rooms, live video, stories and gifting — and how we enforce them."}],["$","meta","2",{"name":"keywords","content":"CALL,calls,video call,voice call,messaging,voice messages,free calls"}],["$","link","3",{"rel":"icon","href":"/logo.svg"}],["$","link","4",{"rel":"apple-touch-icon","href":"/logo.svg"}],["$","$L5","5",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
