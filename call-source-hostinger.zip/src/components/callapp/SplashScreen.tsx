'use client'

import { useEffect, useState } from 'react'
import { api } from '@/lib/callapp/api'
import { CallWordmark } from './CallLogo'
import { useApp } from '@/lib/callapp/store'

/**
 * Splash screen — the admin can disable it from the panel ("App experience").
 *
 * Routing rules:
 *  - splash disabled + logged in      → straight to the app (NEVER get-started)
 *  - splash disabled + not logged in  → get-started screens
 *  - splash enabled                   → animated logo, then app / get-started
 *
 * The decision comes from the server config (with the localStorage cache as a
 * fast-path fallback). When disabled we drop into the neutral 'boot' phase —
 * a plain white screen with a spinner — and let bootstrap() resolve the real
 * destination, so logged-in users never see a blue flash or the get-started
 * screens. A pre-hydration script in layout.tsx neutralizes the shell color
 * (html[data-splash-off]) so even the first paint is white, never navy.
 */
export function SplashScreen() {
  const bootstrap = useApp((s) => s.bootstrap)
  const booted = useApp((s) => s.booted)
  const splashEnabled = useApp((s) => s.splashEnabled)
  /** null = pre-hydration (render nothing), true = show visuals, false = skip */
  const [show, setShow] = useState<boolean | null>(null)

  useEffect(() => {
    // deferred one tick so the first paint matches the server (hydration-safe)
    const t = window.setTimeout(() => {
      void (async () => {
        // 1) ask the server for the admin setting; fall back to the local cache
        let enabled = true
        try {
          const cfg = await api.appConfig()
          enabled = cfg.splashEnabled !== false
        } catch {
          try {
            enabled = window.localStorage.getItem('call.splash') !== '0'
          } catch {}
        }
        try {
          window.localStorage.setItem('call.splash', enabled ? '1' : '0')
        } catch {}
        setShow(enabled)
        useApp.setState({ splashEnabled: enabled })
        if (!enabled) skipToBoot()
        // 2) bootstrap validates the session and picks 'main' or 'onboarding'
        void bootstrap()
      })()
    }, 0)
    return () => window.clearTimeout(t)
  }, [bootstrap])

  useEffect(() => {
    // server said disabled while the cached splash was showing → end it now
    if (show === false || splashEnabled === false) {
      skipToBoot()
      return
    }
    // enabled splash: leave for the app once bootstrap has decided
    if (show && booted) {
      const t = window.setTimeout(() => {
        if (useApp.getState().phase === 'splash') {
          useApp.setState({ phase: useApp.getState().me ? 'main' : 'onboarding' })
        }
      }, 900)
      return () => window.clearTimeout(t)
    }
  }, [booted, show, splashEnabled])

  // disabled (or pre-hydration frame) → nothing; the shell shows a neutral boot screen
  if (!show) return null

  return (
    <div className="bg-dark-grad absolute inset-0 z-50 flex flex-col items-center justify-center text-white">
      <div className="relative flex h-64 w-full items-center justify-center">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="ring-anim absolute h-[110px] w-[110px] rounded-full border-2 border-[#3D6BFF]"
            style={{ animationDelay: `${i}s` }}
          />
        ))}
        <div className="flex h-[104px] w-[104px] items-center justify-center rounded-[28px] bg-white shadow-[0_20px_50px_rgba(20,67,228,0.45)]">
          <CallWordmarkFallback />
        </div>
      </div>
      <div className="mt-6 text-center">
        <h1 className="text-[38px] font-extrabold tracking-tight">CALL</h1>
        <p className="mt-2 text-[15px] text-[#A9B6D3]">One World. One Call.</p>
      </div>
      <div className="absolute bottom-24 left-1/2 h-1 w-32 -translate-x-1/2 overflow-hidden rounded-full bg-[#1B2B52]">
        <div className="loadbar-anim h-full rounded-full bg-[#3D6BFF]" />
      </div>
      <p className="absolute bottom-12 w-full text-center text-xs text-[#6F7FA6]">Peer-to-peer encrypted calls</p>
    </div>
  )
}

/** Leave the splash phase for the neutral boot screen; bootstrap() picks main/onboarding. */
function skipToBoot() {
  if (useApp.getState().phase === 'splash') useApp.setState({ phase: 'boot' })
}

function CallWordmarkFallback() {
  return (
    <svg width="64" height="64" viewBox="0 0 256 256" aria-hidden="true">
      <path
        fill="url(#splashG)"
        d="M 200.6 53.7 A 100 100 0 1 0 200.6 182.3 L 171.5 157.9 A 62 62 0 1 1 171.5 78.1 Z"
      />
      <path fill="url(#splashG)" d="M 122 214 L 34 252 L 36 152 Z" />
      <circle cx="124" cy="118" r="60" fill="#FFFFFF" />
      <path
        fill="url(#splashG2)"
        transform="translate(88 84) scale(3.05)"
        d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"
      />
      <defs>
        <linearGradient id="splashG" x1="60" y1="18" x2="176" y2="242" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#3EC0FF" />
          <stop offset="0.52" stopColor="#2273F2" />
          <stop offset="1" stopColor="#1443E4" />
        </linearGradient>
        <linearGradient id="splashG2" x1="88" y1="70" x2="170" y2="180" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#3AAEFF" />
          <stop offset="1" stopColor="#1B54EF" />
        </linearGradient>
      </defs>
    </svg>
  )
}
